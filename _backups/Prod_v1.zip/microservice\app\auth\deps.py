"""Зависимости FastAPI для проверки сессии веб-кабинета."""
from __future__ import annotations

from fastapi import HTTPException, Request

from app.auth.service import COOKIE_NAME, AuthService


def _auth(request: Request) -> AuthService | None:
    return getattr(request.app.state, "auth", None)


def current_user(request: Request) -> dict | None:
    """Возвращает данные пользователя из cookie-сессии (или None)."""
    svc = _auth(request)
    if svc is None or not svc.auth.enabled:
        # Авторизация отключена — пускаем как анонимного оператора.
        return {"sub": "anonymous", "name": "Оператор", "role": "Оператор"}
    token = request.cookies.get(COOKIE_NAME)
    return svc.verify_token(token)


def require_user(request: Request) -> dict:
    """Гейт для защищённых эндпоинтов: 401, если нет валидной сессии."""
    user = current_user(request)
    if user is None:
        raise HTTPException(status_code=401, detail="Требуется авторизация")
    return user
