"""SQLite-хранилище состояния MAX-бота.

Хранит то, что нельзя держать в Dify (stateful-диалог):
  - users          : пользователи и счётчик заданных вопросов;
  - questions       : история вопросов (для "последних трёх");
  - escalations     : вопросы, переданные операторам;
  - operator_state  : какой оператор сейчас отвечает на какую эскалацию;
  - appointments    : выбранные слоты записи на приём.

Используется только stdlib sqlite3. Соединение открывается на каждую операцию —
для нагрузки бота это с запасом достаточно и безопасно при нескольких воркерах.
"""
from __future__ import annotations

import os
import sqlite3
import time
from contextlib import contextmanager


class Store:
    def __init__(self, path: str):
        self.path = path
        directory = os.path.dirname(path)
        if directory:
            os.makedirs(directory, exist_ok=True)
        self._init_db()

    @contextmanager
    def _conn(self):
        conn = sqlite3.connect(self.path, timeout=10)
        conn.row_factory = sqlite3.Row
        try:
            conn.execute("PRAGMA journal_mode=WAL;")
            yield conn
            conn.commit()
        finally:
            conn.close()

    def _init_db(self) -> None:
        with self._conn() as c:
            c.executescript(
                """
                CREATE TABLE IF NOT EXISTS users (
                    user_id      TEXT PRIMARY KEY,
                    chat_id      TEXT,
                    name         TEXT,
                    username     TEXT,
                    phone        TEXT,
                    question_count INTEGER NOT NULL DEFAULT 0,
                    questions_since_offer INTEGER NOT NULL DEFAULT 0
                );

                CREATE TABLE IF NOT EXISTS questions (
                    id        INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id   TEXT NOT NULL,
                    text      TEXT NOT NULL,
                    created_at REAL NOT NULL
                );

                CREATE TABLE IF NOT EXISTS escalations (
                    id           INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id      TEXT NOT NULL,
                    user_chat_id TEXT NOT NULL,
                    user_name    TEXT,
                    username     TEXT,
                    question     TEXT NOT NULL,
                    status       TEXT NOT NULL DEFAULT 'open',
                    operator_id  TEXT,
                    operator_msg_mid TEXT,
                    created_at   REAL NOT NULL
                );

                CREATE TABLE IF NOT EXISTS operator_state (
                    operator_id   TEXT PRIMARY KEY,
                    escalation_id INTEGER NOT NULL,
                    created_at    REAL NOT NULL
                );

                CREATE TABLE IF NOT EXISTS appointments (
                    id           INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id      TEXT NOT NULL,
                    building_id  TEXT,
                    building_name TEXT,
                    time         TEXT,
                    created_at   REAL NOT NULL
                );

                CREATE TABLE IF NOT EXISTS applications (
                    id            INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id       TEXT NOT NULL,
                    user_chat_id  TEXT,
                    user_name     TEXT,
                    username      TEXT,
                    measure_key   TEXT,
                    measure_title TEXT,
                    status        TEXT NOT NULL DEFAULT 'proposed',
                    data          TEXT,
                    decided_by    TEXT,
                    created_at    REAL NOT NULL,
                    updated_at    REAL NOT NULL,
                    decided_at    REAL
                );
                """
            )
            # Миграции для существующих БД (добавленные позже столбцы).
            self._ensure_column(c, "users", "questions_since_offer", "INTEGER NOT NULL DEFAULT 0")
            self._ensure_column(c, "escalations", "operator_msg_mid", "TEXT")
            # Поля, которыми пользуется веб-кабинет оператора.
            self._ensure_column(c, "escalations", "assignee", "TEXT")
            self._ensure_column(c, "escalations", "answer", "TEXT")
            self._ensure_column(c, "escalations", "answered_at", "REAL")
            self._ensure_column(c, "escalations", "topic", "TEXT")

    @staticmethod
    def _ensure_column(conn, table: str, column: str, ddl: str) -> None:
        cols = {row["name"] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}
        if column not in cols:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")

    # ---- users / questions -------------------------------------------------

    def ensure_user(self, user_id: str, chat_id: str, name: str = "", username: str = "") -> None:
        with self._conn() as c:
            c.execute(
                """
                INSERT INTO users (user_id, chat_id, name, username)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET
                    chat_id = excluded.chat_id,
                    name = COALESCE(NULLIF(excluded.name, ''), users.name),
                    username = COALESCE(NULLIF(excluded.username, ''), users.username)
                """,
                (user_id, chat_id, name, username),
            )

    def get_user(self, user_id: str) -> sqlite3.Row | None:
        with self._conn() as c:
            return c.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)).fetchone()

    def add_question(self, user_id: str, text: str) -> int:
        """Сохраняет вопрос и инкрементит счётчики.

        Возвращает questions_since_offer — число вопросов с момента прошлого предложения
        записи (сбрасывается в 0 после показа оффера, см. reset_since_offer).
        """
        with self._conn() as c:
            c.execute(
                "INSERT INTO questions (user_id, text, created_at) VALUES (?, ?, ?)",
                (user_id, text, time.time()),
            )
            c.execute(
                "UPDATE users SET question_count = question_count + 1, "
                "questions_since_offer = questions_since_offer + 1 WHERE user_id = ?",
                (user_id,),
            )
            row = c.execute(
                "SELECT questions_since_offer FROM users WHERE user_id = ?", (user_id,)
            ).fetchone()
            return int(row["questions_since_offer"]) if row else 1

    def reset_since_offer(self, user_id: str) -> None:
        """Сбрасывает счётчик вопросов до следующего предложения записи."""
        with self._conn() as c:
            c.execute(
                "UPDATE users SET questions_since_offer = 0 WHERE user_id = ?", (user_id,)
            )

    def last_questions(self, user_id: str, n: int = 3) -> list[str]:
        with self._conn() as c:
            rows = c.execute(
                "SELECT text FROM questions WHERE user_id = ? ORDER BY id DESC LIMIT ?",
                (user_id, n),
            ).fetchall()
        return [r["text"] for r in reversed(rows)]

    # ---- escalations -------------------------------------------------------

    def create_escalation(
        self, user_id: str, user_chat_id: str, user_name: str, username: str, question: str
    ) -> int:
        with self._conn() as c:
            cur = c.execute(
                """
                INSERT INTO escalations
                    (user_id, user_chat_id, user_name, username, question, status, created_at)
                VALUES (?, ?, ?, ?, ?, 'open', ?)
                """,
                (user_id, user_chat_id, user_name, username, question, time.time()),
            )
            return int(cur.lastrowid)

    def get_escalation(self, escalation_id: int) -> sqlite3.Row | None:
        with self._conn() as c:
            return c.execute(
                "SELECT * FROM escalations WHERE id = ?", (escalation_id,)
            ).fetchone()

    def set_escalation_mid(self, escalation_id: int, mid: str) -> None:
        """Запоминает id сообщения-эскалации в чате операторов (для ответа через reply)."""
        with self._conn() as c:
            c.execute(
                "UPDATE escalations SET operator_msg_mid = ? WHERE id = ?", (mid, escalation_id)
            )

    def get_open_escalation_by_mid(self, mid: str) -> sqlite3.Row | None:
        with self._conn() as c:
            return c.execute(
                "SELECT * FROM escalations WHERE operator_msg_mid = ? AND status = 'open' "
                "ORDER BY id DESC LIMIT 1",
                (mid,),
            ).fetchone()

    def close_escalation(self, escalation_id: int, operator_id: str) -> None:
        with self._conn() as c:
            c.execute(
                "UPDATE escalations SET status = 'answered', operator_id = ? WHERE id = ?",
                (operator_id, escalation_id),
            )

    # ---- operator reply state ---------------------------------------------

    def set_operator_state(self, operator_id: str, escalation_id: int) -> None:
        with self._conn() as c:
            c.execute(
                """
                INSERT INTO operator_state (operator_id, escalation_id, created_at)
                VALUES (?, ?, ?)
                ON CONFLICT(operator_id) DO UPDATE SET
                    escalation_id = excluded.escalation_id,
                    created_at = excluded.created_at
                """,
                (operator_id, escalation_id, time.time()),
            )

    def pop_operator_state(self, operator_id: str) -> int | None:
        """Возвращает escalation_id, на который отвечает оператор, и снимает состояние."""
        with self._conn() as c:
            row = c.execute(
                "SELECT escalation_id FROM operator_state WHERE operator_id = ?",
                (operator_id,),
            ).fetchone()
            if not row:
                return None
            c.execute("DELETE FROM operator_state WHERE operator_id = ?", (operator_id,))
            return int(row["escalation_id"])

    # ---- appointments ------------------------------------------------------

    def create_appointment(
        self, user_id: str, building_id: str, building_name: str, time_str: str
    ) -> int:
        with self._conn() as c:
            cur = c.execute(
                """
                INSERT INTO appointments
                    (user_id, building_id, building_name, time, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (user_id, building_id, building_name, time_str, time.time()),
            )
            return int(cur.lastrowid)

    # ---- заявления (мера поддержки по фото) --------------------------------

    def create_application(
        self, user_id: str, user_chat_id: str, user_name: str, username: str,
        measure_key: str, measure_title: str, data: str, status: str = "proposed",
    ) -> int:
        now = time.time()
        with self._conn() as c:
            cur = c.execute(
                """
                INSERT INTO applications
                    (user_id, user_chat_id, user_name, username, measure_key,
                     measure_title, status, data, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (user_id, user_chat_id, user_name, username, measure_key,
                 measure_title, status, data, now, now),
            )
            return int(cur.lastrowid)

    def get_application(self, application_id: int) -> sqlite3.Row | None:
        with self._conn() as c:
            return c.execute(
                "SELECT * FROM applications WHERE id = ?", (application_id,)
            ).fetchone()

    def update_application_data(self, application_id: int, data: str) -> None:
        with self._conn() as c:
            c.execute(
                "UPDATE applications SET data = ?, updated_at = ? WHERE id = ?",
                (data, time.time(), application_id),
            )

    def set_application_status(
        self, application_id: int, status: str, decided_by: str | None = None
    ) -> None:
        now = time.time()
        with self._conn() as c:
            if decided_by is not None:
                c.execute(
                    "UPDATE applications SET status = ?, decided_by = ?, decided_at = ?, "
                    "updated_at = ? WHERE id = ?",
                    (status, decided_by, now, now, application_id),
                )
            else:
                c.execute(
                    "UPDATE applications SET status = ?, updated_at = ? WHERE id = ?",
                    (status, now, application_id),
                )

    def list_applications(self, limit: int = 500) -> list[sqlite3.Row]:
        with self._conn() as c:
            return c.execute(
                "SELECT * FROM applications ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()

    def delete_application(self, application_id: int) -> bool:
        with self._conn() as c:
            cur = c.execute("DELETE FROM applications WHERE id = ?", (application_id,))
            return cur.rowcount > 0

    # ---- read-only выборки для веб-кабинета --------------------------------

    def list_escalations(self, limit: int = 500) -> list[sqlite3.Row]:
        with self._conn() as c:
            return c.execute(
                "SELECT * FROM escalations ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()

    def count_escalations(self) -> int:
        with self._conn() as c:
            return int(c.execute("SELECT COUNT(*) AS n FROM escalations").fetchone()["n"])

    def list_questions(self, limit: int = 2000) -> list[sqlite3.Row]:
        with self._conn() as c:
            return c.execute(
                "SELECT * FROM questions ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()

    def list_appointments(self, limit: int = 1000) -> list[sqlite3.Row]:
        with self._conn() as c:
            return c.execute(
                "SELECT * FROM appointments ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()

    def set_escalation_assignee(self, escalation_id: int, assignee: str) -> None:
        with self._conn() as c:
            self._ensure_column(c, "escalations", "assignee", "TEXT")
            c.execute(
                "UPDATE escalations SET assignee = ? WHERE id = ?", (assignee, escalation_id)
            )

    def set_escalation_answer(self, escalation_id: int, answer: str, assignee: str = "") -> None:
        """Сохраняет ответ оператора, данный из веб-кабинета, и закрывает обращение."""
        with self._conn() as c:
            self._ensure_column(c, "escalations", "answer", "TEXT")
            self._ensure_column(c, "escalations", "answered_at", "REAL")
            self._ensure_column(c, "escalations", "assignee", "TEXT")
            if assignee:
                c.execute(
                    "UPDATE escalations SET answer = ?, answered_at = ?, status = 'answered', "
                    "assignee = ? WHERE id = ?",
                    (answer, time.time(), assignee, escalation_id),
                )
            else:
                c.execute(
                    "UPDATE escalations SET answer = ?, answered_at = ?, status = 'answered' "
                    "WHERE id = ?",
                    (answer, time.time(), escalation_id),
                )

    def delete_escalation(self, escalation_id: int) -> bool:
        """Удаляет обращение оператора из веб-кабинета."""
        with self._conn() as c:
            c.execute("DELETE FROM operator_state WHERE escalation_id = ?", (escalation_id,))
            cur = c.execute("DELETE FROM escalations WHERE id = ?", (escalation_id,))
            return cur.rowcount > 0
