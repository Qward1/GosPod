"""Сервисный слой веб-кабинета: обращения, карточки УСВО, аналитика, ИИ.

Связывает источники данных (таблица УСВО, SQLite-состояние бота, Dify) в формат,
удобный фронтенду. Реальные обращения берутся из таблицы `escalations` (их создаёт
MAX-бот). Если их ещё нет и включён `web.seed_appeals` — показываются обращения,
синтезированные из реальных карточек УСВО. Ответы на такие обращения хранятся в
памяти процесса.
"""
from __future__ import annotations

import datetime as dt
import json
import random
import re
import sqlite3
import time

from app.config import Config
from app.docs.forms import application_summary, build_application_docx, normalize_application
from app.max.client import MaxClient
from app.max.dify_client import DifyClient
from app.max.store import Store
from app.web import ai
from app.web.analytics import build_analytics
from app.web.history import build_history
from app.web.topics import classify_topic
from app.web.usvo import UsvoRecord, UsvoStore

APP_STATUS_LABELS = {
    "proposed": "Предложено гражданину",
    "awaiting_confirm": "Ожидает подтверждения",
    "submitted": "Подано — на рассмотрении",
    "approved": "Одобрено",
    "rejected": "Отклонено",
}

SEED_QUESTIONS = [
    "Как оформить статус ветерана боевых действий?",
    "Какие выплаты положены после ранения?",
    "Положена ли компенсация за санаторно-курортное лечение?",
    "Как получить помощь в трудоустройстве?",
    "Можно ли пройти бесплатное переобучение?",
    "Какие льготы есть на оплату ЖКХ?",
    "Как записаться на психологическую консультацию?",
    "Положена ли матери погибшего пенсия по потере кормильца?",
    "Как получить технические средства реабилитации?",
    "Какие меры поддержки есть для детей участника СВО?",
    "Нужна юридическая консультация по жилищному вопросу.",
    "Как вступить в ассоциацию ветеранов СВО?",
]


def _digits(s: str) -> str:
    return re.sub(r"\D", "", s or "")


class WebService:
    def __init__(
        self,
        cfg: Config,
        store: Store,
        usvo_store: UsvoStore,
        dify: DifyClient,
        max_client: MaxClient,
    ):
        self.cfg = cfg
        self.store = store
        self.usvo = usvo_store
        self.dify = dify
        self.max_client = max_client
        self._seed_appeals: list[dict] | None = None
        self._seed_appointments = 0

    def _operators(self) -> list[str]:
        return [op.strip() for op in self.cfg.web.operators if op.strip()] or ["Оператор администрации"]

    # ---- совместимость со старыми Store на сервере ------------------------

    def _store_path(self) -> str:
        return getattr(self.store, "path", self.cfg.storage.sqlite_path)

    def _ensure_column(self, conn, table: str, column: str, ddl: str) -> None:
        cols = {row["name"] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}
        if column not in cols:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")

    def _count_escalations(self) -> int:
        if hasattr(self.store, "count_escalations"):
            return int(self.store.count_escalations())
        with sqlite3.connect(self._store_path(), timeout=10) as conn:
            conn.row_factory = sqlite3.Row
            return int(conn.execute("SELECT COUNT(*) AS n FROM escalations").fetchone()["n"])

    def _list_escalations(self) -> list:
        if hasattr(self.store, "list_escalations"):
            return self.store.list_escalations()
        with sqlite3.connect(self._store_path(), timeout=10) as conn:
            conn.row_factory = sqlite3.Row
            return conn.execute("SELECT * FROM escalations ORDER BY id DESC LIMIT 500").fetchall()

    def _get_escalation(self, escalation_id: int):
        if hasattr(self.store, "get_escalation"):
            return self.store.get_escalation(escalation_id)
        with sqlite3.connect(self._store_path(), timeout=10) as conn:
            conn.row_factory = sqlite3.Row
            return conn.execute("SELECT * FROM escalations WHERE id = ?", (escalation_id,)).fetchone()

    def _set_escalation_assignee(self, escalation_id: int, assignee: str) -> None:
        if hasattr(self.store, "set_escalation_assignee"):
            self.store.set_escalation_assignee(escalation_id, assignee)
            return
        with sqlite3.connect(self._store_path(), timeout=10) as conn:
            conn.row_factory = sqlite3.Row
            self._ensure_column(conn, "escalations", "assignee", "TEXT")
            conn.execute("UPDATE escalations SET assignee = ? WHERE id = ?", (assignee, escalation_id))

    def _set_escalation_answer(self, escalation_id: int, answer: str, assignee: str = "") -> None:
        if hasattr(self.store, "set_escalation_answer"):
            self.store.set_escalation_answer(escalation_id, answer, assignee)
            return
        with sqlite3.connect(self._store_path(), timeout=10) as conn:
            conn.row_factory = sqlite3.Row
            self._ensure_column(conn, "escalations", "answer", "TEXT")
            self._ensure_column(conn, "escalations", "answered_at", "REAL")
            self._ensure_column(conn, "escalations", "assignee", "TEXT")
            if assignee:
                conn.execute(
                    "UPDATE escalations SET answer = ?, answered_at = ?, status = 'answered', "
                    "assignee = ? WHERE id = ?",
                    (answer, time.time(), assignee, escalation_id),
                )
            else:
                conn.execute(
                    "UPDATE escalations SET answer = ?, answered_at = ?, status = 'answered' WHERE id = ?",
                    (answer, time.time(), escalation_id),
                )

    def _delete_escalation(self, escalation_id: int) -> bool:
        if hasattr(self.store, "delete_escalation"):
            return bool(self.store.delete_escalation(escalation_id))
        with sqlite3.connect(self._store_path(), timeout=10) as conn:
            conn.row_factory = sqlite3.Row
            conn.execute("DELETE FROM operator_state WHERE escalation_id = ?", (escalation_id,))
            cur = conn.execute("DELETE FROM escalations WHERE id = ?", (escalation_id,))
            return cur.rowcount > 0

    def _list_appointments(self) -> list:
        if hasattr(self.store, "list_appointments"):
            return self.store.list_appointments()
        with sqlite3.connect(self._store_path(), timeout=10) as conn:
            conn.row_factory = sqlite3.Row
            return conn.execute("SELECT * FROM appointments ORDER BY id DESC LIMIT 1000").fetchall()

    # ---- сопоставление гражданина с карточкой УСВО -------------------------

    def _match_usvo(self, name: str = "", phone: str = "") -> UsvoRecord | None:
        ph = _digits(phone)
        recs = self.usvo.all()
        if ph:
            for r in recs:
                rec_phone = _digits(r.phone)
                if rec_phone and (ph in rec_phone or rec_phone in ph):
                    return r
        nm = (name or "").strip().lower()
        if nm:
            for r in recs:
                if nm and (nm in r.name.lower() or r.name.lower() in nm):
                    return r
        return None

    # ---- синтезированные обращения ----------------------------------------

    def _build_seed_appeals(self) -> list[dict]:
        recs = self.usvo.all()
        operators = self._operators()
        rng = random.Random(42)  # детерминированно — стабильный набор
        sample = recs[:12] if len(recs) >= 12 else recs
        out: list[dict] = []
        now = time.time()
        for i, rec in enumerate(sample):
            q = SEED_QUESTIONS[i % len(SEED_QUESTIONS)]
            created = now - rng.randint(0, 18) * 86400 - rng.randint(0, 86400)
            answered = i % 3 == 0  # каждое третье — отвечено
            out.append({
                "id": f"seed-{i+1}",
                "real": False,
                "question": q,
                "created_at": created,
                "topic": classify_topic(q),
                "assignee": operators[i % len(operators)],
                "status": "answered" if answered else "open",
                "answer": "Ответ направлен гражданину." if answered else "",
                "citizen": {"name": rec.name, "phone": rec.phone, "username": ""},
                "usvo_id": rec.id,
            })
        self._seed_appointments = sum(1 for a in out if a["status"] == "answered")
        out.sort(key=lambda a: a["created_at"], reverse=True)
        return out

    def _seeded_appeals(self) -> list[dict]:
        if self._seed_appeals is None:
            self._seed_appeals = self._build_seed_appeals()
        return self._seed_appeals

    def _use_seeded_appeals(self) -> bool:
        return self.cfg.web.seed_appeals and self._count_escalations() == 0

    # ---- обращения ---------------------------------------------------------

    def _escalation_to_appeal(self, row) -> dict:
        d = dict(row)
        question = d.get("question") or ""
        topic = d.get("topic") or classify_topic(question)
        usvo = self._match_usvo(d.get("user_name") or "", "")
        return {
            "id": f"esc-{d['id']}",
            "real": True,
            "question": question,
            "created_at": d.get("created_at") or 0,
            "topic": topic,
            "assignee": d.get("assignee") or "",
            "status": d.get("status") or "open",
            "answer": d.get("answer") or "",
            "citizen": {
                "name": d.get("user_name") or "",
                "phone": "",
                "username": d.get("username") or "",
            },
            "usvo_id": usvo.id if usvo else None,
        }

    def list_appeals(self) -> list[dict]:
        if self._use_seeded_appeals():
            appeals = list(self._seeded_appeals())
        else:
            appeals = [self._escalation_to_appeal(r) for r in self._list_escalations()]
        for a in appeals:
            a["created_human"] = _human_ts(a["created_at"])
        return appeals

    def get_appeal(self, appeal_id: str) -> dict | None:
        for a in self.list_appeals():
            if a["id"] == appeal_id:
                return a
        return None

    def set_assignee(self, appeal_id: str, assignee: str) -> dict | None:
        assignee = (assignee or "").strip()
        if appeal_id.startswith("esc-"):
            self._set_escalation_assignee(int(appeal_id[4:]), assignee)
        else:
            for a in self._seeded_appeals():
                if a["id"] == appeal_id:
                    a["assignee"] = assignee
        return self.get_appeal(appeal_id)

    async def draft(self, appeal_id: str, operator: str) -> dict:
        appeal = self.get_appeal(appeal_id)
        if not appeal:
            return {"error": "not_found"}
        usvo = self.usvo.get(appeal["usvo_id"]) if appeal.get("usvo_id") else None
        if usvo is None:
            usvo = self._match_usvo(appeal["citizen"]["name"], appeal["citizen"]["phone"])
        return await ai.draft_reply(
            self.cfg, self.dify,
            question=appeal["question"],
            usvo=usvo,
            operator=(operator or "").strip() or self._operators()[0],
        )

    async def answer(self, appeal_id: str, answer_text: str, assignee: str) -> dict:
        appeal = self.get_appeal(appeal_id)
        if not appeal:
            return {"error": "not_found"}
        assignee = (assignee or "").strip()

        delivered = False
        kb_saved = False
        if appeal["real"] and appeal_id.startswith("esc-"):
            esc_id = int(appeal_id[4:])
            self._set_escalation_answer(esc_id, answer_text, assignee)
            # запись ответа в базу знаний (как делает бот) — best-effort
            try:
                res = await self.dify.add_to_kb(appeal["question"], answer_text)
                kb_saved = not res.get("skipped")
            except Exception:  # noqa: BLE001
                kb_saved = False
            # отправка ответа гражданину в MAX — best-effort
            row = self._get_escalation(esc_id)
            if row and row["user_id"] and (self.cfg.max.bot_token or "").strip() and \
                    "xxxx" not in self.cfg.max.bot_token.lower():
                try:
                    await self.max_client.send_message(answer_text, user_id=row["user_id"])
                    delivered = True
                except Exception:  # noqa: BLE001
                    delivered = False
        else:
            for a in self._seeded_appeals():
                if a["id"] == appeal_id:
                    a["status"] = "answered"
                    a["answer"] = answer_text
                    if assignee:
                        a["assignee"] = assignee

        return {"ok": True, "delivered_to_citizen": delivered, "saved_to_kb": kb_saved,
                "appeal": self.get_appeal(appeal_id)}

    def delete_appeal(self, appeal_id: str) -> dict:
        if appeal_id.startswith("esc-"):
            deleted = self._delete_escalation(int(appeal_id[4:]))
            return {"ok": deleted}
        before = len(self._seeded_appeals())
        self._seed_appeals = [a for a in self._seeded_appeals() if a["id"] != appeal_id]
        return {"ok": len(self._seed_appeals) < before}

    # ---- карточки УСВО -----------------------------------------------------

    def list_usvo(self, query: str = "") -> list[dict]:
        recs = self.usvo.all()
        q = (query or "").strip().lower()
        q_digits = _digits(q)
        out = []
        for r in recs:
            haystack = " ".join(
                [r.name, r.short_name, r.phone or "", r.status or "", r.address or ""]
            ).lower()
            if q and q not in haystack and (not q_digits or q_digits not in _digits(r.phone)):
                continue
            out.append({
                "id": r.id, "name": r.name, "short_name": r.short_name,
                "initials": r.initials, "status": r.status, "phone": r.phone,
                "call_date": r.call_date, "address": r.address,
                "flags": r.flags,
                "head_directive": r.head_directive,
            })
        return out

    def get_usvo(self, rec_id: int) -> dict | None:
        r = self.usvo.get(rec_id)
        if not r:
            return None
        d = r.as_dict()
        appeals = [a for a in self.list_appeals() if a.get("usvo_id") == rec_id]
        d["appeals"] = appeals
        # Наполненная лента: синтетические события + реальные обращения.
        d["history"] = build_history(r, appeals)
        return d

    async def suggestions(self, rec_id: int) -> dict:
        r = self.usvo.get(rec_id)
        if not r:
            return {"error": "not_found"}
        return await ai.suggest_measures(self.cfg, self.dify, usvo=r)

    # ---- заявления (мера поддержки по фото) --------------------------------

    def _application_to_dict(self, row) -> dict:
        d = dict(row)
        try:
            data = normalize_application(json.loads(d.get("data") or "{}"))
        except Exception:  # noqa: BLE001
            data = normalize_application({})
        status = d.get("status") or "proposed"
        usvo = self._match_usvo(d.get("user_name") or "", "")
        return {
            "id": d["id"],
            "measure_key": d.get("measure_key") or data.get("measure_key"),
            "measure_title": d.get("measure_title") or data.get("measure_title"),
            "status": status,
            "status_label": APP_STATUS_LABELS.get(status, status),
            "citizen": {
                "name": d.get("user_name") or data["applicant"].get("fio") or "",
                "username": d.get("username") or "",
            },
            "applicant": data["applicant"],
            "category": data["category"],
            "category_code": data["category_code"],
            "ownership": data["ownership"],
            "rooms": data["rooms"],
            "family": data["family"],
            "providers": data["providers"],
            "payment": data["payment"],
            "missing": data["missing"],
            "summary": application_summary(data),
            "decided_by": d.get("decided_by") or "",
            "usvo_id": usvo.id if usvo else None,
            "created_at": d.get("created_at") or 0,
            "created_human": _human_ts(d.get("created_at") or 0),
            "updated_human": _human_ts(d.get("updated_at") or 0),
            "downloadable": status in ("submitted", "approved", "awaiting_confirm"),
        }

    def list_applications(self) -> list[dict]:
        # В админ-разделе показываем только то, что гражданин подтвердил и подал.
        rows = self.store.list_applications()
        return [
            self._application_to_dict(r) for r in rows
            if (r["status"] if not isinstance(r, dict) else r.get("status")) in
            ("submitted", "approved", "rejected")
        ]

    def get_application(self, application_id: int) -> dict | None:
        row = self.store.get_application(application_id)
        return self._application_to_dict(row) if row else None

    def decide_application(self, application_id: int, decision: str, operator: str) -> dict:
        row = self.store.get_application(application_id)
        if not row:
            return {"ok": False}
        self.store.set_application_status(application_id, decision, operator or "Администрация")
        # Уведомить заявителя в MAX — best-effort, не блокируя ответ кабинету.
        chat_id = row["user_chat_id"]
        token = (self.cfg.max.bot_token or "").lower()
        if chat_id and token and "xxxx" not in token:
            verb = "одобрено" if decision == "approved" else "отклонено"
            tail = ("Ожидайте назначения выплаты." if decision == "approved"
                    else "Свяжитесь с оператором для уточнения деталей.")
            msg = f"Ваше заявление «{row['measure_title']}» {verb} специалистом администрации. {tail}"
            self._send_max_async(msg, chat_id)
        return {"ok": True, "application": self.get_application(application_id)}

    def _send_max_async(self, text: str, chat_id: str) -> None:
        """Планирует отправку сообщения в MAX из работающего event loop (best-effort)."""
        import asyncio
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return
        loop.create_task(self.max_client.send_message(text, chat_id=chat_id))

    def delete_application(self, application_id: int) -> dict:
        return {"ok": self.store.delete_application(application_id)}

    def application_docx(self, application_id: int) -> bytes | None:
        row = self.store.get_application(application_id)
        if not row:
            return None
        try:
            data = normalize_application(json.loads(row["data"] or "{}"))
        except Exception:  # noqa: BLE001
            data = normalize_application({})
        return build_application_docx(data)

    def _count_submitted_applications(self) -> int:
        return sum(
            1 for r in self.store.list_applications()
            if (r["status"] if not isinstance(r, dict) else r.get("status"))
            in ("submitted", "approved")
        )

    # ---- аналитика ---------------------------------------------------------

    def analytics(self) -> dict:
        appeals = self.list_appeals()
        appeal_times = [a["created_at"] for a in appeals if a["created_at"]]
        appeal_topics = [a["topic"] for a in appeals]
        if self._use_seeded_appeals():
            appointment_count = self._seed_appointments
        else:
            appointment_count = len(self._list_appointments())
        return build_analytics(
            self.usvo.all(), appeal_times, appeal_topics,
            appointment_count, self.cfg.web.contact_stale_days,
            applications=self._count_submitted_applications(),
        )

    def meta(self) -> dict:
        web_ai = getattr(self.cfg.web, "ai", None)
        web_ai_provider = getattr(web_ai, "provider", "local") if web_ai else "local"
        web_ai_ready = ai.dify_ready(self.cfg)
        return {
            "title": self.cfg.web.title,
            "operators": self._operators(),
            "usvo_error": self.usvo.error,
            "dify_ready": web_ai_ready,
            "web_ai_provider": web_ai_provider,
            "web_ai_ready": web_ai_ready,
            "seeded_appeals": self._use_seeded_appeals(),
        }


def _human_ts(ts: float) -> str:
    if not ts:
        return "—"
    return dt.datetime.fromtimestamp(ts).strftime("%d.%m.%Y %H:%M")
