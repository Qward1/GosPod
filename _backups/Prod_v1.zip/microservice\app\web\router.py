"""HTTP API веб-кабинета «Контакт-центр» (раздаётся на том же внешнем порту).

Все эндпоинты под /api/web/*. Статические файлы интерфейса монтируются в main.py.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel

from app.auth.deps import require_user
from app.web.service import WebService

# Все эндпоинты кабинета защищены сессией (см. app/auth). Логин-эндпоинты вынесены
# в отдельный роутер /api/web/auth/* и под этот гейт не попадают.
router = APIRouter(prefix="/api/web", tags=["web"], dependencies=[Depends(require_user)])


def _svc(request: Request) -> WebService:
    svc = getattr(request.app.state, "web", None)
    if svc is None:
        raise HTTPException(status_code=503, detail="Веб-кабинет отключён (web.enabled=false)")
    return svc


class AssigneeBody(BaseModel):
    assignee: str = ""


class DraftBody(BaseModel):
    operator: str = ""


class AnswerBody(BaseModel):
    answer: str
    assignee: str = ""


@router.get("/meta")
async def meta(request: Request) -> dict:
    return _svc(request).meta()


# ---- обращения -------------------------------------------------------------

@router.get("/appeals")
async def appeals(request: Request) -> dict:
    return {"items": _svc(request).list_appeals()}


@router.get("/appeals/{appeal_id}")
async def appeal(request: Request, appeal_id: str) -> dict:
    a = _svc(request).get_appeal(appeal_id)
    if not a:
        raise HTTPException(status_code=404, detail="Обращение не найдено")
    return a


@router.post("/appeals/{appeal_id}/assignee")
async def set_assignee(request: Request, appeal_id: str, body: AssigneeBody) -> dict:
    a = _svc(request).set_assignee(appeal_id, body.assignee)
    if not a:
        raise HTTPException(status_code=404, detail="Обращение не найдено")
    return a


@router.post("/appeals/{appeal_id}/draft")
async def draft(request: Request, appeal_id: str, body: DraftBody) -> dict:
    res = await _svc(request).draft(appeal_id, body.operator)
    if res.get("error") == "not_found":
        raise HTTPException(status_code=404, detail="Обращение не найдено")
    return res


@router.post("/appeals/{appeal_id}/answer")
async def answer(request: Request, appeal_id: str, body: AnswerBody) -> dict:
    if not body.answer.strip():
        raise HTTPException(status_code=400, detail="Пустой ответ")
    res = await _svc(request).answer(appeal_id, body.answer, body.assignee)
    if res.get("error") == "not_found":
        raise HTTPException(status_code=404, detail="Обращение не найдено")
    return res


@router.delete("/appeals/{appeal_id}")
async def delete_appeal(request: Request, appeal_id: str) -> dict:
    res = _svc(request).delete_appeal(appeal_id)
    if not res.get("ok"):
        raise HTTPException(status_code=404, detail="Обращение не найдено")
    return res


# ---- карточки УСВО ---------------------------------------------------------

@router.get("/usvo")
async def usvo_list(request: Request, query: str = "") -> dict:
    return {"items": _svc(request).list_usvo(query)}


@router.get("/usvo/{rec_id}")
async def usvo_get(request: Request, rec_id: int) -> dict:
    r = _svc(request).get_usvo(rec_id)
    if not r:
        raise HTTPException(status_code=404, detail="Карточка не найдена")
    return r


@router.get("/usvo/{rec_id}/suggestions")
async def usvo_suggestions(request: Request, rec_id: int) -> dict:
    res = await _svc(request).suggestions(rec_id)
    if res.get("error") == "not_found":
        raise HTTPException(status_code=404, detail="Карточка не найдена")
    return res


# ---- заявления (мера поддержки по фото) ------------------------------------

class DecisionBody(BaseModel):
    operator: str = ""


@router.get("/applications")
async def applications(request: Request) -> dict:
    return {"items": _svc(request).list_applications()}


@router.get("/applications/{application_id}")
async def application(request: Request, application_id: int) -> dict:
    a = _svc(request).get_application(application_id)
    if not a:
        raise HTTPException(status_code=404, detail="Заявление не найдено")
    return a


@router.post("/applications/{application_id}/approve")
async def approve_application(request: Request, application_id: int, body: DecisionBody) -> dict:
    res = _svc(request).decide_application(application_id, "approved", body.operator)
    if not res.get("ok"):
        raise HTTPException(status_code=404, detail="Заявление не найдено")
    return res


@router.post("/applications/{application_id}/reject")
async def reject_application(request: Request, application_id: int, body: DecisionBody) -> dict:
    res = _svc(request).decide_application(application_id, "rejected", body.operator)
    if not res.get("ok"):
        raise HTTPException(status_code=404, detail="Заявление не найдено")
    return res


@router.delete("/applications/{application_id}")
async def delete_application(request: Request, application_id: int) -> dict:
    res = _svc(request).delete_application(application_id)
    if not res.get("ok"):
        raise HTTPException(status_code=404, detail="Заявление не найдено")
    return res


@router.get("/applications/{application_id}/docx")
async def application_docx(request: Request, application_id: int) -> Response:
    data = _svc(request).application_docx(application_id)
    if data is None:
        raise HTTPException(status_code=404, detail="Заявление не найдено")
    return Response(
        content=data,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={"Content-Disposition": f'attachment; filename="zayavlenie-{application_id}.docx"'},
    )


# ---- аналитика -------------------------------------------------------------

@router.get("/analytics")
async def analytics(request: Request) -> dict:
    return _svc(request).analytics()
