"""Логика MAX-бота: ответы из БЗ, эскалация операторам, запись на приём.

Вся stateful-часть (то, что Dify вести не может) живёт здесь:
  - счётчик вопросов и предложение записи после каждых N вопросов
    (счётчик ведётся ОТ ПРОШЛОГО предложения и сбрасывается при показе оффера);
  - эскалация неуверенных ответов в чат операторов с inline-кнопкой «Ответить»;
  - захват ответа оператора (кнопка «Ответить» ИЛИ reply на сообщение-эскалацию),
    доставка пользователю + запись в базу знаний + отчёт в чат операторов;
  - выбор слота и отправка заявки операторам (контакты + последние 3 вопроса + время).
"""
from __future__ import annotations

import json
import logging

from app.config import Config
from app.docs.doc_ai import DocAI
from app.docs.forms import application_summary, build_application_docx, normalize_application
from app.max.client import MaxClient
from app.max.dify_client import DifyClient
from app.max.schedule import find_building, iter_slots
from app.max.store import Store

log = logging.getLogger("max.bot")

# Тексты бота — в одном месте, чтобы их было удобно править.
MSG_ESCALATED = "Спасибо за вопрос! Он передан оператору — мы ответим вам в ближайшее время."
MSG_OFFER = "Не хотите записаться на приём?"
MSG_PICK_TIME = "Выберите удобное для вас время:"
MSG_OFFER_DECLINED = "Хорошо! Можете продолжать задавать вопросы."
MSG_APPT_CONFIRMED = "Заявка на приём принята. Оператор свяжется с вами для подтверждения."
MSG_OPERATOR_PROMPT = "Введите ответ одним сообщением — он будет отправлен пользователю."

# Запрос не по теме контакт-центра: отвечаем базовым сообщением и НЕ эскалируем операторам.
MSG_OFF_TOPIC = (
    "Я — ассистент контакт-центра господдержки участников СВО и их семей. "
    "Помогаю по вопросам мер поддержки, выплат и льгот, медицинской и социальной "
    "реабилитации, трудоустройства, жилья, юридической и психологической помощи, "
    "оформления документов и записи на приём.\n\n"
    "Кажется, ваш вопрос не относится к этим темам. Пожалуйста, переформулируйте его "
    "в рамках господдержки СВО — и я постараюсь помочь."
)

# Сценарий оформления меры поддержки по фотографиям документов.
MSG_DOC_ANALYZING = (
    "Получил фотографии документов. Анализирую их с помощью ИИ — это займёт несколько секунд…"
)
MSG_DOC_DECLINED = "Хорошо, оформление отменено. Если передумаете — пришлите фото документов снова."


class MaxBot:
    def __init__(
        self, cfg: Config, store: Store, max_client: MaxClient, dify: DifyClient,
        doc_ai: DocAI | None = None,
    ):
        self.cfg = cfg
        self.store = store
        self.max = max_client
        self.dify = dify
        self.doc_ai = doc_ai or DocAI(cfg)
        self.operator_chat_id = str(cfg.max.operator_chat_id)

    # ====================================================================
    # Точка входа: разбор апдейта MAX
    # ====================================================================
    async def handle_update(self, update: dict) -> None:
        update_type = update.get("update_type") or update.get("type")
        try:
            if update_type == "message_callback":
                await self._handle_callback(update)
            elif update_type in ("message_created", "message", None):
                message = update.get("message") or update
                await self._handle_message(message)
            else:
                log.info("Пропущен update_type=%s", update_type)
        except Exception:  # noqa: BLE001 — webhook не должен падать целиком
            log.exception("Ошибка обработки апдейта")

    # ====================================================================
    # Входящее текстовое сообщение
    # ====================================================================
    async def _handle_message(self, message: dict) -> None:
        sender = message.get("sender") or {}
        recipient = message.get("recipient") or {}
        body = message.get("body") or {}

        text = (body.get("text") or message.get("text") or "").strip()
        image_urls = _image_urls(message)

        user_id = _id(sender.get("user_id"))
        chat_id = _id(recipient.get("chat_id")) or user_id
        name = sender.get("name") or sender.get("first_name") or ""
        username = sender.get("username") or ""

        # Фото документов от гражданина (не в чате операторов) → сценарий оформления
        # меры поддержки по документам.
        if image_urls and chat_id != self.operator_chat_id:
            await self._handle_documents(user_id, chat_id, name, username, image_urls)
            return

        if not text:
            return

        log.info(
            "Входящее сообщение: chat_id=%s operator_chat_id=%s match=%s sender=%s text=%r",
            chat_id, self.operator_chat_id, chat_id == self.operator_chat_id, user_id, text[:60],
        )

        # Сообщение в чате операторов: возможно, это ответ оператора на эскалацию.
        if chat_id and chat_id == self.operator_chat_id:
            reply_mid = _reply_mid(message)
            log.info("Чат операторов: reply_mid=%s, ищу активную эскалацию", reply_mid)
            await self._handle_operator_message(user_id, name, text, reply_mid)
            return

        await self._handle_user_question(user_id, chat_id, name, username, text)

    async def _handle_user_question(
        self, user_id: str, chat_id: str, name: str, username: str, text: str
    ) -> None:
        self.store.ensure_user(user_id, chat_id, name, username)
        since_offer = self.store.add_question(user_id, text)

        result = await self.dify.ask(text, user_key=f"max-{user_id}")

        # Тематический фильтр: запросы не по теме контакт-центра отклоняются базовым
        # сообщением и НЕ доходят до операторов. Off-topic, если модель пометила
        # on_topic=false с достаточной уверенностью (topic_confidence ≥ порога).
        off_topic = (not result.get("on_topic", True)) and (
            result.get("topic_confidence", 0.0) >= self.cfg.max.topic_threshold
        )
        if off_topic:
            log.info(
                "Запрос отклонён фильтром (off-topic, topic_confidence=%.2f): %r",
                result.get("topic_confidence", 0.0), text[:60],
            )
            await self.max.send_message(MSG_OFF_TOPIC, chat_id=chat_id, user_id=user_id)
            return

        needs_operator = (not result["found_in_kb"]) or (
            result["confidence"] < self.cfg.max.confidence_threshold
        )

        if needs_operator:
            esc_id = self.store.create_escalation(user_id, chat_id, name, username, text)
            await self._notify_operators_escalation(esc_id, name, username, text)
            await self.max.send_message(MSG_ESCALATED, chat_id=chat_id, user_id=user_id)
        else:
            await self.max.send_message(result["answer"], chat_id=chat_id, user_id=user_id)

        # Предложение записи: счётчик ведётся ОТ прошлого предложения и сбрасывается.
        if since_offer >= self.cfg.max.questions_before_offer:
            await self._offer_appointment(chat_id, user_id)
            self.store.reset_since_offer(user_id)

    # ====================================================================
    # Ответ оператора
    # ====================================================================
    async def _handle_operator_message(
        self, operator_id: str, operator_name: str, text: str, reply_mid: str | None
    ) -> None:
        # 1) оператор нажал «Ответить» → состояние; 2) или ответил reply-ом на эскалацию.
        escalation_id = self.store.pop_operator_state(operator_id)
        source = "кнопка «Ответить»"
        if escalation_id is None and reply_mid:
            esc = self.store.get_open_escalation_by_mid(reply_mid)
            if esc:
                escalation_id = int(esc["id"])
                source = "reply на эскалацию"

        if escalation_id is None:
            log.info(
                "Сообщение в чате операторов без активной эскалации (operator=%s) — игнор.",
                operator_id,
            )
            return

        log.info("Ответ оператора на эскалацию #%s (%s)", escalation_id, source)
        await self._process_operator_answer(escalation_id, operator_id, operator_name, text)

    async def _process_operator_answer(
        self, escalation_id: int, operator_id: str, operator_name: str, text: str
    ) -> None:
        esc = self.store.get_escalation(escalation_id)
        if not esc:
            await self.max.send_message(
                f"Эскалация #{escalation_id} не найдена.", chat_id=self.operator_chat_id
            )
            return

        # 1) ответ пользователю
        await self.max.send_message(f"Ответ оператора:\n{text}", chat_id=esc["user_chat_id"])
        # 2) запись в выбранную базу знаний
        kb = await self.dify.add_to_kb(esc["question"], text)
        kb_status = _kb_status(kb)
        # 3) закрытие эскалации
        self.store.set_escalation_answer(escalation_id, text, operator_name or operator_id)
        self.store.close_escalation(escalation_id, operator_id)

        # 4) отчёт в чат операторов
        contact = (esc["user_name"] or "пользователь")
        if esc["username"]:
            contact += f" (@{esc['username']})"
        contact += f", id {esc['user_id']}"
        report = (
            f"✅ Ответ отправлен (эскалация #{escalation_id})\n\n"
            f"👤 Оператор: {operator_name or operator_id}\n"
            f"📨 Кому: {contact}\n"
            f"❓ Вопрос: {esc['question']}\n"
            f"💬 Ответ: {text}\n"
            f"📚 Запись в базу знаний: {kb_status}"
        )
        await self.max.send_message(report, chat_id=self.operator_chat_id)

    # ====================================================================
    # Callback-и от inline-кнопок
    # ====================================================================
    async def _handle_callback(self, update: dict) -> None:
        callback = update.get("callback") or {}
        callback_id = callback.get("callback_id")
        user = callback.get("user") or {}
        message = update.get("message") or {}
        recipient = message.get("recipient") or {}

        user_id = _id(user.get("user_id"))
        chat_id = _id(recipient.get("chat_id")) or user_id
        name = user.get("name") or user.get("first_name") or ""
        username = user.get("username") or ""
        source_mid = _msg_mid(message)  # сообщение, на котором была кнопка

        payload = _parse_payload(callback.get("payload"))
        action = payload.get("a")

        if action == "yes":  # «Записаться»
            await self.max.answer_callback(callback_id)
            await self._delete_if(source_mid)
            await self._send_slots(chat_id, user_id)
        elif action == "no":  # «Отказаться» → сообщение-оффер пропадает
            await self.max.answer_callback(callback_id, MSG_OFFER_DECLINED)
            await self._delete_if(source_mid)
        elif action == "slot":  # выбран слот → убираем список слотов
            await self.max.answer_callback(callback_id)
            await self._delete_if(source_mid)
            await self._handle_slot_selection(
                user_id, chat_id, name, username, payload.get("b", ""), payload.get("t", "")
            )
        elif action == "ans":  # оператор берёт эскалацию в ответ
            await self._claim_escalation(callback_id, user_id, name, int(payload.get("e", 0)))
        elif action == "doc_make":  # гражданин согласился оформить меру → заполняем заявление
            await self.max.answer_callback(callback_id)
            await self._delete_if(source_mid)
            await self._finalize_application(user_id, chat_id, int(payload.get("p", 0)))
        elif action == "doc_ok":  # гражданин подтвердил заполненное заявление → подаём
            await self.max.answer_callback(callback_id)
            await self._delete_if(source_mid)
            await self._submit_application(user_id, chat_id, name, username, int(payload.get("p", 0)))
        elif action == "doc_no":  # отказ от оформления
            await self.max.answer_callback(callback_id, MSG_DOC_DECLINED)
            await self._delete_if(source_mid)
            await self._cancel_application(int(payload.get("p", 0)))
            await self.max.send_message(MSG_DOC_DECLINED, chat_id=chat_id, user_id=user_id)
        else:
            await self.max.answer_callback(callback_id)

    async def _delete_if(self, message_id: str | None) -> None:
        if message_id:
            await self.max.delete_message(message_id)

    async def _claim_escalation(
        self, callback_id: str, operator_id: str, operator_name: str, escalation_id: int
    ) -> None:
        esc = self.store.get_escalation(escalation_id)
        if not esc or esc["status"] != "open":
            await self.max.answer_callback(callback_id, "Эскалация уже обработана.")
            return
        self.store.set_operator_state(operator_id, escalation_id)
        await self.max.answer_callback(callback_id, MSG_OPERATOR_PROMPT)
        await self.max.send_message(
            f"Оператор {operator_name or operator_id} отвечает на вопрос #{escalation_id}.\n"
            f"{MSG_OPERATOR_PROMPT}",
            chat_id=self.operator_chat_id,
        )

    # ====================================================================
    # Оформление меры поддержки по фотографиям документов
    # ====================================================================
    async def _handle_documents(
        self, user_id: str, chat_id: str, name: str, username: str, image_urls: list[str]
    ) -> None:
        """Шаг 1: ИИ анализирует фото документов и предлагает меру поддержки."""
        self.store.ensure_user(user_id, chat_id, name, username)
        await self.max.send_message(MSG_DOC_ANALYZING, chat_id=chat_id, user_id=user_id)

        extracted = await self.doc_ai.analyze_documents(image_urls, user_key=f"max-doc-{user_id}")
        app = normalize_application(extracted)

        application_id = self.store.create_application(
            user_id, chat_id, name or app["applicant"]["fio"], username,
            app["measure_key"], app["measure_title"],
            json.dumps(extracted, ensure_ascii=False), status="proposed",
        )

        note = app.get("summary_note") or ""
        text = (
            "🔍 Готово! По вашим документам ИИ определил доступную меру поддержки:\n\n"
            f"✅ {app['measure_title']}\n"
            f"Основание: {app['category']}.\n\n"
        )
        if note:
            text += f"{note}\n\n"
        text += "Оформить заявление автоматически на основании ваших документов?"
        rows = [[
            {"text": "Оформить", "payload": json.dumps({"a": "doc_make", "p": application_id})},
            {"text": "Отказаться", "payload": json.dumps({"a": "doc_no", "p": application_id})},
        ]]
        await self.max.send_message(text, chat_id=chat_id, user_id=user_id, keyboard_rows=rows)

    async def _finalize_application(self, user_id: str, chat_id: str, application_id: int) -> None:
        """Шаг 2: ИИ заполняет заявление и присылает файл на подтверждение."""
        row = self.store.get_application(application_id)
        if not row:
            return
        try:
            extracted = json.loads(row["data"] or "{}")
        except Exception:  # noqa: BLE001
            extracted = {}

        filled = await self.doc_ai.fill_application(extracted, user_key=f"max-doc-{user_id}")
        self.store.update_application_data(application_id, json.dumps(filled, ensure_ascii=False))
        self.store.set_application_status(application_id, "awaiting_confirm")

        docx_bytes = build_application_docx(filled)
        caption = (
            "📄 Заявление заполнено. Проверьте данные и подтвердите отправку:\n\n"
            f"{application_summary(filled)}"
        )
        rows = [[
            {"text": "Подтвердить и подать", "payload": json.dumps({"a": "doc_ok", "p": application_id})},
            {"text": "Отказаться", "payload": json.dumps({"a": "doc_no", "p": application_id})},
        ]]
        sent = await self.max.send_document(
            docx_bytes, "Заявление.docx", chat_id=chat_id, user_id=user_id,
            caption=caption, keyboard_rows=rows,
        )
        if not sent.get("ok"):
            # Фолбэк, если отправка файла недоступна: текстовое превью + кнопки.
            await self.max.send_message(caption, chat_id=chat_id, user_id=user_id, keyboard_rows=rows)

    async def _submit_application(
        self, user_id: str, chat_id: str, name: str, username: str, application_id: int
    ) -> None:
        """Шаг 3: гражданин подтвердил → заявление подаётся в администрацию."""
        row = self.store.get_application(application_id)
        if not row:
            return
        self.store.set_application_status(application_id, "submitted")
        try:
            filled = normalize_application(json.loads(row["data"] or "{}"))
        except Exception:  # noqa: BLE001
            filled = normalize_application({})

        await self.max.send_message(
            "✅ Заявление принято и направлено в администрацию Ленинского городского "
            "округа. Статус рассмотрения сообщим в этом чате.",
            chat_id=chat_id, user_id=user_id,
        )
        # Уведомление в чат операторов.
        contact = name or "гражданин"
        if username:
            contact += f" (@{username})"
        operator_text = (
            "🆕 Новое заявление на меру поддержки\n\n"
            f"Заявитель: {contact}\n"
            f"Мера: {row['measure_title']}\n"
            f"{application_summary(filled)}\n\n"
            f"Открыть в кабинете → раздел «Заявления» (#{application_id})."
        )
        await self.max.send_message(operator_text, chat_id=self.operator_chat_id)

    async def _cancel_application(self, application_id: int) -> None:
        if application_id:
            self.store.set_application_status(application_id, "rejected", "гражданин (отказ)")

    # ====================================================================
    # Запись на приём
    # ====================================================================
    async def _offer_appointment(self, chat_id: str, user_id: str = "") -> None:
        rows = [[
            {"text": "Записаться", "payload": json.dumps({"a": "yes"})},
            {"text": "Отказаться", "payload": json.dumps({"a": "no"})},
        ]]
        await self.max.send_message(MSG_OFFER, chat_id=chat_id, user_id=user_id, keyboard_rows=rows)

    async def _send_slots(self, chat_id: str, user_id: str = "") -> None:
        slots = iter_slots(self.cfg.schedule_file)
        if not slots:
            await self.max.send_message(
                "Свободных слотов пока нет. Попробуйте позже.", chat_id=chat_id, user_id=user_id
            )
            return

        rows: list[list[dict]] = []
        for s in slots:
            payload = json.dumps({"a": "slot", "b": s.building_id, "t": s.time})
            rows.append([{"text": f"{s.building_short} · {s.time}", "payload": payload}])

        await self.max.send_message(MSG_PICK_TIME, chat_id=chat_id, user_id=user_id, keyboard_rows=rows)

    async def _handle_slot_selection(
        self, user_id: str, chat_id: str, name: str, username: str,
        building_id: str, time_str: str,
    ) -> None:
        self.store.ensure_user(user_id, chat_id, name, username)
        building = find_building(self.cfg.schedule_file, building_id) or {}
        building_name = building.get("name", building_id)
        self.store.create_appointment(user_id, building_id, building_name, time_str)

        last3 = self.store.last_questions(user_id, 3)
        history = "\n".join(f"  {i + 1}. {q}" for i, q in enumerate(last3)) or "  (нет вопросов)"
        contact = f"{name}".strip() or user_id
        if username:
            contact += f" (@{username})"

        operator_text = (
            "🗓 Новая заявка на приём\n\n"
            f"Контакты: {contact}\n"
            f"ID пользователя: {user_id}\n"
            f"Здание: {building_name}\n"
            f"Адрес: {building.get('address', '')}\n"
            f"Время: {time_str}\n\n"
            f"Последние вопросы пользователя:\n{history}"
        )
        await self.max.send_message(operator_text, chat_id=self.operator_chat_id)
        await self.max.send_message(
            f"{MSG_APPT_CONFIRMED}\n\n{building_name}\n{building.get('address', '')}\nВремя: {time_str}",
            chat_id=chat_id, user_id=user_id,
        )

    # ====================================================================
    # Эскалация в чат операторов
    # ====================================================================
    async def _notify_operators_escalation(
        self, escalation_id: int, name: str, username: str, question: str
    ) -> None:
        contact = name or "пользователь"
        if username:
            contact += f" (@{username})"
        text = (
            f"❓ Вопрос требует оператора (#{escalation_id})\n\n"
            f"От: {contact}\n"
            f"Вопрос: {question}\n\n"
            f"Нажмите «Ответить» или ответьте reply-ом на это сообщение."
        )
        rows = [[{"text": "Ответить", "payload": json.dumps({"a": "ans", "e": escalation_id})}]]
        res = await self.max.send_message(text, chat_id=self.operator_chat_id, keyboard_rows=rows)
        # Запоминаем id сообщения-эскалации, чтобы принять ответ через reply.
        mid = _msg_mid(res)
        if mid:
            self.store.set_escalation_mid(escalation_id, mid)


def _id(value) -> str:
    return "" if value is None else str(value)


def _kb_status(kb) -> str:
    """Человекочитаемый статус записи ответа в базу знаний (Dify Dataset API)."""
    if not isinstance(kb, dict):
        return "ошибка — см. логи сервиса"
    if kb.get("skipped"):
        return "пропущена (датасет не настроен)"
    # Успех Dify create-by-text: возвращает document/batch (или id).
    if kb.get("document") or kb.get("batch") or kb.get("id"):
        return "да"
    return "ошибка — см. логи сервиса"


def _msg_mid(obj) -> str | None:
    """Достаёт id сообщения (mid). Принимает и объект сообщения, и ответ MAX на отправку."""
    if not isinstance(obj, dict):
        return None
    m = obj.get("message", obj)
    if isinstance(m, dict):
        body = m.get("body") or {}
        return body.get("mid") or m.get("mid")
    return None


def _reply_mid(message: dict) -> str | None:
    """id сообщения, на которое отвечают reply-ом (если это reply)."""
    link = message.get("link") or {}
    if isinstance(link, dict):
        body = link.get("message") or {}
        return link.get("mid") or (body.get("mid") if isinstance(body, dict) else None)
    return None


def _image_urls(message: dict) -> list[str]:
    """Извлекает URL фотографий из вложений сообщения MAX.

    MAX кладёт картинки в body.attachments с type=image/photo; ссылка может лежать
    в payload.url или payload.photos[*].url (формат немного разнится по версиям).
    """
    body = message.get("body") or message
    attachments = body.get("attachments") or message.get("attachments") or []
    urls: list[str] = []
    for att in attachments:
        if not isinstance(att, dict):
            continue
        if att.get("type") not in ("image", "photo"):
            continue
        payload = att.get("payload") or {}
        url = payload.get("url")
        if url:
            urls.append(url)
            continue
        photos = payload.get("photos")
        if isinstance(photos, dict):
            for ph in photos.values():
                if isinstance(ph, dict) and ph.get("url"):
                    urls.append(ph["url"])
        elif isinstance(photos, list):
            for ph in photos:
                if isinstance(ph, dict) and ph.get("url"):
                    urls.append(ph["url"])
    return urls


def _parse_payload(raw) -> dict:
    if isinstance(raw, dict):
        return raw
    if not raw:
        return {}
    try:
        parsed = json.loads(raw)
        return parsed if isinstance(parsed, dict) else {}
    except Exception:
        return {}
