"""Точка входа FastAPI-микросервиса "Господдержка СВО".

Запуск:
    uvicorn app.main:app --host 0.0.0.0 --port 8080

Путь к конфигу: ./config.yaml (или переменная окружения CONFIG_PATH).
"""
from __future__ import annotations

import asyncio
import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from app.auth.router import router as auth_router
from app.auth.service import AuthService
from app.common.health import router as common_router
from app.config import get_config
from app.docs.doc_ai import DocAI
from app.excel.router import router as excel_router
from app.max.bot_logic import MaxBot
from app.max.client import MaxClient
from app.max.dify_client import DifyClient
from app.max.polling import poll_loop
from app.max.router import router as max_router
from app.max.store import Store
from app.web.router import router as web_router
from app.web.service import WebService
from app.web.usvo import UsvoStore

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    cfg = get_config()

    # Состояние и клиенты MAX-бота поднимаем один раз на всё приложение.
    store = Store(cfg.storage.sqlite_path)
    max_client = MaxClient(cfg.max.api_base_url, cfg.max.bot_token)
    dify = DifyClient(
        base_url=cfg.dify.base_url,
        app_key=cfg.dify.max_app_key,
        dataset_api_key=cfg.dify.dataset.api_key,
        dataset_id=cfg.dify.dataset.dataset_id,
    )
    doc_ai = DocAI(cfg)
    app.state.cfg = cfg
    app.state.store = store
    app.state.auth = AuthService(cfg)
    app.state.bot = MaxBot(cfg, store, max_client, dify, doc_ai)

    # Веб-кабинет «Контакт-центр» — на том же внешнем порту.
    if cfg.web.enabled:
        usvo_store = UsvoStore(cfg.web.usvo_xlsx, cfg.web.contact_stale_days)
        app.state.web = WebService(cfg, store, usvo_store, dify, max_client)
        if usvo_store.error:
            logging.getLogger("app").warning("Таблица УСВО: %s", usvo_store.error)
        logging.getLogger("app").info("Веб-кабинет включён: GET / (записей УСВО: %d).",
                                      len(usvo_store.all()))

    poll_task = None
    if cfg.max.polling:
        poll_task = asyncio.create_task(poll_loop(app.state.bot, max_client))
        logging.getLogger("app").info("Фоновый long polling MAX включён (max.polling=true).")

    logging.getLogger("app").info("Сервис запущен. Конфиг загружен.")
    try:
        yield
    finally:
        if poll_task is not None:
            poll_task.cancel()
            try:
                await poll_task
            except asyncio.CancelledError:
                pass


app = FastAPI(title="Господдержка СВО — микросервис", version="1.0.0", lifespan=lifespan)

app.include_router(common_router)
app.include_router(excel_router)
app.include_router(max_router)
app.include_router(auth_router)
app.include_router(web_router)

# Статика веб-кабинета. Монтируется ПОСЛЕ всех роутеров, чтобы не перехватывать
# API-пути. html=True отдаёт index.html на корневой путь "/".
_STATIC_DIR = os.path.join(os.path.dirname(__file__), "web", "static")
if get_config().web.enabled and os.path.isdir(_STATIC_DIR):
    app.mount("/", StaticFiles(directory=_STATIC_DIR, html=True), name="web-static")
