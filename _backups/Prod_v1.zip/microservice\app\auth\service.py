"""Авторизация веб-кабинета в стиле ЕСИА на базе Ory Kratos.

Вход устроен как «свой логин-экран → наш бэкенд проверяет учётку → ставим
подписанную cookie-сессию». Сама проверка учётных данных делается одним из двух
способов (config `auth.mode`):

  • demo   — по локальному списку `auth.demo_users` (работает сразу, без Kratos);
  • kratos — через Identity API Kratos (self-service login flow типа `api`),
             что не требует браузерных redirect/CSRF.

Cookie-сессия кабинета — собственная (HMAC-SHA256 по `auth.session_secret`), не
зависит от cookie Kratos: это позволяет одинаково гейтить и demo-, и kratos-режим
и не пробрасывать домены. Всё разворачивается на сервере (deploy/kratos/).
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import logging
import time

import httpx

from app.config import Config

log = logging.getLogger("auth")


class AuthService:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.auth = cfg.auth

    # ---- проверка учётных данных -------------------------------------------

    async def authenticate(self, identifier: str, password: str) -> dict | None:
        """Проверяет логин/пароль. Возвращает {sub, name, role} или None."""
        identifier = (identifier or "").strip()
        password = password or ""
        if not identifier or not password:
            return None
        mode = (self.auth.mode or "demo").strip().lower()
        if mode == "kratos":
            return await self._authenticate_kratos(identifier, password)
        return self._authenticate_demo(identifier, password)

    def _authenticate_demo(self, identifier: str, password: str) -> dict | None:
        for u in self.auth.demo_users:
            if str(u.get("identifier", "")).strip().lower() == identifier.lower() \
                    and str(u.get("password", "")) == password:
                return {
                    "sub": identifier,
                    "name": u.get("name") or identifier,
                    "role": u.get("role") or "Оператор",
                }
        return None

    async def _authenticate_kratos(self, identifier: str, password: str) -> dict | None:
        base = (self.auth.kratos_public_url or "").rstrip("/")
        try:
            async with httpx.AsyncClient(timeout=20.0) as client:
                flow = await client.get(
                    f"{base}/self-service/login/api",
                    headers={"Accept": "application/json"},
                )
                if flow.status_code >= 400:
                    log.error("Kratos login flow error %s: %s", flow.status_code, flow.text[:300])
                    return None
                flow_id = flow.json().get("id")
                resp = await client.post(
                    f"{base}/self-service/login",
                    params={"flow": flow_id},
                    headers={"Accept": "application/json", "Content-Type": "application/json"},
                    json={"method": "password", "identifier": identifier, "password": password},
                )
        except Exception as exc:  # noqa: BLE001
            log.warning("Kratos недоступен (%s) — вход отклонён", exc)
            return None

        if resp.status_code >= 400:
            log.info("Kratos отклонил вход для %s: %s", identifier, resp.status_code)
            return None
        data = resp.json()
        identity = (data.get("session") or {}).get("identity") or {}
        traits = identity.get("traits") or {}
        name = traits.get("name")
        if isinstance(name, dict):
            name = " ".join(filter(None, [name.get("first"), name.get("last")]))
        return {
            "sub": identity.get("id") or identifier,
            "name": name or traits.get("email") or identifier,
            "role": traits.get("role") or "Оператор",
        }

    # ---- cookie-сессия (HMAC) ----------------------------------------------

    def issue_token(self, user: dict) -> str:
        payload = {
            "sub": user["sub"],
            "name": user["name"],
            "role": user.get("role", "Оператор"),
            "exp": int(time.time()) + self.auth.session_ttl_hours * 3600,
        }
        raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        body = base64.urlsafe_b64encode(raw).rstrip(b"=")
        sig = self._sign(body)
        return f"{body.decode()}.{sig}"

    def verify_token(self, token: str | None) -> dict | None:
        if not token or "." not in token:
            return None
        body, _, sig = token.rpartition(".")
        if not hmac.compare_digest(sig, self._sign(body.encode())):
            return None
        try:
            padded = body + "=" * (-len(body) % 4)
            payload = json.loads(base64.urlsafe_b64decode(padded))
        except Exception:  # noqa: BLE001
            return None
        if int(payload.get("exp", 0)) < int(time.time()):
            return None
        return payload

    def _sign(self, body: bytes) -> str:
        secret = (self.auth.session_secret or "change-me").encode("utf-8")
        digest = hmac.new(secret, body, hashlib.sha256).digest()
        return base64.urlsafe_b64encode(digest).rstrip(b"=").decode()


COOKIE_NAME = "cc_session"
