"""Клиент Dify: вызов MAX-ветки воркфлоу и запись ответов оператора в базу знаний."""
from __future__ import annotations

import datetime as dt
import json
import logging

import httpx

log = logging.getLogger("max.dify")


class DifyClient:
    def __init__(
        self,
        base_url: str,
        app_key: str,
        dataset_api_key: str,
        dataset_id: str,
        timeout: float = 60.0,
    ):
        self.base_url = base_url.rstrip("/")
        self.app_key = app_key
        self.dataset_api_key = dataset_api_key
        self.dataset_id = dataset_id
        self.timeout = timeout

    async def ask(self, query: str, user_key: str) -> dict:
        """Спрашивает MAX-ветку Dify. Ожидает, что answer-узел вернёт JSON-строку
        вида {"answer": str, "found_in_kb": bool, "confidence": number}.

        Возвращает нормализованный dict с ключами answer / found_in_kb / confidence.
        При сбое парсинга считаем, что ответа в БЗ нет (escalate), чтобы вопрос не
        потерялся — лучше отдать оператору, чем выдать сырой текст без проверки.
        """
        if not _configured(self.app_key):
            log.warning("Dify app_key не настроен — вопрос будет передан оператору")
            return {
                "answer": "", "found_in_kb": False, "confidence": 0.0,
                "on_topic": True, "topic_confidence": 0.0,
            }

        url = f"{self.base_url}/chat-messages"
        headers = {
            "Authorization": f"Bearer {self.app_key}",
            "Content-Type": "application/json",
        }
        body = {
            "inputs": {"channel": "max"},
            "query": query,
            "response_mode": "blocking",
            "user": user_key,
        }
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.post(url, headers=headers, json=body)
            if resp.status_code >= 400:
                log.error("Dify ask error %s: %s", resp.status_code, resp.text)
                return {
                    "answer": "", "found_in_kb": False, "confidence": 0.0,
                    "on_topic": True, "topic_confidence": 0.0,
                }
            data = resp.json()

        raw_answer = data.get("answer", "")
        return _parse_structured(raw_answer)

    async def add_to_kb(self, question: str, answer: str) -> dict:
        """Записывает пару вопрос/ответ в выбранную базу знаний (Dataset API)."""
        if not _configured(self.dataset_id) or not _configured(self.dataset_api_key):
            log.warning("Dataset не настроен — пропускаю запись в базу знаний")
            return {"skipped": True}

        url = f"{self.base_url}/datasets/{self.dataset_id}/document/create-by-text"
        headers = {
            "Authorization": f"Bearer {self.dataset_api_key}",
            "Content-Type": "application/json",
        }
        stamp = dt.datetime.now().strftime("%Y-%m-%d %H:%M")
        body = {
            "name": f"Ответ оператора {stamp}",
            "text": f"Вопрос: {question}\nОтвет: {answer}",
            "indexing_technique": "high_quality",
            "process_rule": {"mode": "automatic"},
        }
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.post(url, headers=headers, json=body)
            if resp.status_code >= 400:
                log.error("Dify add_to_kb error %s: %s", resp.status_code, resp.text)
            try:
                return resp.json()
            except json.JSONDecodeError:
                return {"_status": resp.status_code, "_text": resp.text}


def _configured(value: str) -> bool:
    text = (value or "").strip().lower()
    if not text:
        return False
    placeholders = ("xxxxxxxx", "change-me", "replace_with", "replace-with")
    return not any(marker in text for marker in placeholders)


def _parse_structured(raw: str) -> dict:
    text = (raw or "").strip()
    text = text.replace("```json", "").replace("```", "").strip()
    parsed = None
    try:
        parsed = json.loads(text)
    except Exception:
        start, end = text.find("{"), text.rfind("}")
        if start >= 0 and end > start:
            try:
                parsed = json.loads(text[start : end + 1])
            except Exception:
                parsed = None

    if not isinstance(parsed, dict):
        # Не смогли распарсить — отправляем на эскалацию (тему считаем релевантной,
        # чтобы не отсечь живого человека из-за сбоя парсинга).
        return {
            "answer": text, "found_in_kb": False, "confidence": 0.0,
            "on_topic": True, "topic_confidence": 0.0,
        }

    try:
        confidence = float(parsed.get("confidence", 0.0))
    except (TypeError, ValueError):
        confidence = 0.0
    try:
        topic_confidence = float(parsed.get("topic_confidence", 0.0))
    except (TypeError, ValueError):
        topic_confidence = 0.0

    return {
        "answer": str(parsed.get("answer", "")).strip(),
        "found_in_kb": bool(parsed.get("found_in_kb", False)),
        "confidence": confidence,
        # При отсутствии поля считаем запрос релевантным (обратная совместимость).
        "on_topic": bool(parsed.get("on_topic", True)),
        "topic_confidence": topic_confidence,
    }
