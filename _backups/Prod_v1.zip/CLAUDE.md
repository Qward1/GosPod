# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Что это

Проект «Господдержка СВО» — два связанных артефакта:

1. **`assistant.yml`** — экспорт Dify-приложения (`advanced-chat`), оркестрация всех сценариев.
   Импортируется в Dify, не запускается локально.
2. **`microservice/`** — FastAPI-сервис на Python. Делает две вещи: (а) извлекает данные из Excel
   для задания 1; (б) содержит **всю stateful-логику MAX-бота** (задание 2) — Dify не умеет вести
   диалог с callback-ами, счётчиками и операторами.

Исходные файлы пользователя (`Информация для базы знаний.txt`, `Spravka_Shablon (1).docx`,
`USVO_*.xlsx`, `Ассистент Цифровой Офис.yml`) — это входные данные/референс, не код.

## Команды (выполнять из `microservice/`)

```bash
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8080      # запуск сервиса

# Настройка/диагностика MAX-бота (нужен заполненный config.yaml):
python maxctl.py me                  # проверить токен (GET /me)
python maxctl.py subscriptions       # текущие подписки на вебхук
python maxctl.py subscribe <https-url>/max/webhook
python maxctl.py unsubscribe <https-url>/max/webhook
python maxctl.py poll                # long polling (для localhost без публичного HTTPS)
```

Формального тест-фреймворка/линтера нет. Проверка делается так:
```bash
python -m compileall -q app maxctl.py          # синтаксис
# поведение — через fastapi.testclient.TestClient (одноразовые скрипты) и фейковые
# MaxClient/DifyClient для прогона bot_logic без сети.
```

## Архитектура: Dify (`assistant.yml`)

Граф — дерево с **роутером на старте**. В `Start` есть текстовый вход `channel`:
- `channel == "max"` → ветка MAX: `knowledge-retrieval` → LLM (structured_output) → code `max_pack`
  → answer. **Ответ — это JSON-строка** `{answer, found_in_kb, confidence, on_topic, topic_confidence}`,
  которую парсит микросервис. **Тематический фильтр живёт в системном промпте `max_llm`**: модель сама
  классифицирует, относится ли запрос к профилю контакт-центра (господдержка СВО, помощь УСВО и семьям,
  получение информации по этим темам), и заполняет `on_topic`/`topic_confidence`. Все 5 полей —
  `required` в схеме structured_output, и `max_pack` обязан их прокидывать. Ветка MAX **физически
  не связана рёбрами** с заданием 1 — это и есть требуемая изоляция.
- иначе → задание 1: `http-request` (в микросервис `/excel/extract`) → code `parse_excel`
  → `question-classifier` (2 класса) → «Вопрос по таблице» (LLM→answer) или «Создание справки»
  (LLM→code `build_docx`→tool `generate_docx`→answer с файлом).

При правках графа держать в голове: модель `qwen3-32b-fp8-v2` (`langgenius/openai_api_compatible`),
лимит входа **32k токенов**; DOCX через плагин `scibox/document-generator`; узлы `dataset_ids` и URL
микросервиса — плейсхолдеры (`REPLACE_WITH_KB_DATASET_ID`, `CHANGE-ME-microservice`), их выбирают/
правят после импорта. Шаблон справки использует фиксированный набор плейсхолдеров: `approver_position`,
`approver_name`, `reference_title`, `task_title`, `reference_date`, `protocol_number`,
`tasks_completed` — `build_docx` обязан отдавать ровно их.

## Архитектура: микросервис (`microservice/app/`)

- `config.py` — конфиг грузится из **YAML, не из .env** (на сервере `.env` запрещён). Путь:
  `CONFIG_PATH` или `./config.yaml`. `get_config()` кэширует.
- `excel/extractor.py` — ключевая логика влезания в 32k: длинные названия столбцов выносятся в
  **легенду один раз**, в записях идут индексы `[N]`, пустые ячейки выбрасываются. Бюджет
  `excel.max_chars` (60000 ≈ 30k токенов) с флагом `truncated`. `/excel/extract` принимает файл
  тремя способами (multipart `file` / `file_url` / raw body) — нарочно, чтобы не зависеть от версии Dify.
- `max/` — бот: `router.py` (вебхук) → `bot_logic.py` (вся логика) → `client.py` (MAX API),
  `dify_client.py` (вызов MAX-ветки Dify + запись в БЗ через Dataset API), `store.py` (SQLite-состояние),
  `schedule.py` (читает `data/schedule.yaml` на каждый запрос), `polling.py` (общий цикл long polling).
- `main.py` — lifespan создаёт `Store`, `MaxClient`, `DifyClient`, `DocAI`, `AuthService`, `MaxBot`
  в `app.state`; при `max.polling=true` поднимает фоновый `poll_loop`.
- `auth/` — авторизация веб-кабинета в стиле ЕСИА (бэкенд на Ory Kratos). `service.py` (demo/kratos +
  HMAC-cookie-сессия), `router.py` (`/api/web/auth/login|logout|whoami|config`), `deps.py`
  (`require_user`, им router-level защищён весь `/api/web/*`). Демо-режим работает без Kratos; реальный
  Kratos — `deploy/kratos/`. Гейт фронта — клиентский (whoami → `login.html`). **В самом интерфейсе
  (`login.html`) название «Ory Kratos» намеренно не упоминается** — только нейтральные формулировки;
  при правке UI не возвращать его в видимый текст.
- `docs/` — сценарий «мера поддержки по фото»: `forms.py` (схема заявления ЖКУ + сборка .docx через
  `common/docx.py`, без сторонних либ), `doc_ai.py` (`DocAI`: визуальная модель Dify
  `doc_vision_app_key` → предложение меры; ассистент `doc_fill_app_key` → заполнение; у обоих
  детерминированный офлайн-фолбэк). Промты — `PROMPTS.md`; Dify-ассистенты — `vision_assistant.yml`
  (VL-распознавание, шаг ①) и `document_assistant.yml` (заполнение + generate_docx, шаг ②).
  Клиент MAX (`client.py`) при 400 на отправку по `chat_id` повторяет по `user_id` (личный диалог).
- MAX-бот (`bot_logic.py`) кроме вопросов ведёт **flow по фото**: `_handle_documents` (фото → анализ
  → оффер «Оформить») → callback `doc_make` (`_finalize_application`: заполнить + прислать .docx) →
  callback `doc_ok` (`_submit_application`: статус `submitted`, уведомить операторов). Заявления —
  таблица `applications` (`store.py`), видны в админ-разделе «Заявления».
- **Тематический фильтр запросов** (`_handle_user_question`): после `dify.ask` запрос считается
  off-topic, если `on_topic=false` И `topic_confidence ≥ max.topic_threshold` (по умолчанию 0.5) —
  тогда бот отвечает базовым `MSG_OFF_TOPIC` и **прекращает обработку: ни ответа из БЗ, ни эскалации
  операторам**. При низкой уверенности фильтра / сбое парсинга (`dify_client._parse_structured`
  по умолчанию `on_topic=True`) запрос идёт обычным путём — чтобы не отсечь живого человека.
- Веб-кабинет — 4 раздела: Обращения, Карточки УСВО, **Заявления** (над аналитикой), Аналитика.
  У части карточек УСВО — строка «Поручение Главы округа» (`usvo.py::_head_directive`). Аналитика
  наполнена демо-данными + **тепловая карта** Ленинского ГО с заметкой ИИ (`analytics.py`).
- **Тепловая карта** — настоящая интерактивная карта Leaflet (CDN `unpkg`, плагин `leaflet.heat`),
  тайлы OpenStreetMap. `analytics.py` отдаёт `heatmap.center` + `hotspots` с **реальными гео-координатами**
  (`lat`/`lng`) посёлков Ленинского ГО; `app.js::initHeatmapMap` строит карту после вставки разметки
  в DOM (heat-слой + кликабельные маркеры-очаги). Требует сети для тайлов; без неё видны маркеры/heat
  на сером фоне. **Координаты hotspots — это lat/lng, не проценты** (была стилизованная картинка).
- **Медали** на карточках УСВО (`static/medals.js`): для наград с реальным фото (`static/medals/*` —
  «Орден Мужества», «За отвагу», «За боевые отличия», «Благодарность командования») отдаётся `<img>`,
  для остальных — стилизованный SVG-фолбэк. `Medals.resolve(text) → [{name, html}]` (раньше было `svg`).
  Сопоставление — по подстрокам в `MEDALS[].match`; новые фото класть в `static/medals/` ASCII-именем
  и добавлять `img:` в нужную запись.

`data/schedule.yaml` — намеренно человекочитаемый, **часто меняемый** файл (здания + слоты),
перечитывается на каждый запрос без перезапуска.

## Особенности MAX Bot API (выучено на практике — легко споткнуться)

- База **`https://platform-api.max.ru`**, авторизация заголовком **`Authorization: <token>`**
  (НЕ query `?access_token=`; старый `botapi.max.ru` устарел).
- В `POST /messages` получатель (`chat_id`/`user_id`) идёт **query-параметром**, иначе ответ
  400 `"Unknown recipient"`.
- **Бот получает `message_created` из группового чата, только если он там администратор.** Callback-и
  (нажатия кнопок) приходят всегда. Поэтому ответ оператора в чате операторов не дойдёт до бота, пока
  бот не админ — это не баг кода.
- Два режима доставки, **взаимоисключающие**: webhook (нужен публичный HTTPS с доверенным серт.) или
  long polling. Нельзя держать активную подписку и polling одновременно.
- Ответ оператора ловится двумя путями: кнопка «Ответить» (ставит `operator_state`) ИЛИ **reply** на
  сообщение-эскалацию (матч по сохранённому `operator_msg_mid`).

## Состояние и счётчики (`store.py`)

SQLite с авто-миграциями (`_ensure_column`) — новые столбцы добавляются к существующей `state.db`,
ничего удалять не нужно. Предложение записи на приём считается по `questions_since_offer` (сбрасывается
в 0 при показе оффера) — это «считать от прошлого предложения», а не по абсолютному счётчику.
