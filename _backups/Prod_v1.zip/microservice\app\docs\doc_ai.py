"""ИИ-обработка документов: анализ фото (визуальная модель) и заполнение заявления.

Два шага сценария «оформление меры поддержки по фото» (MAX-бот):

  1. analyze_documents(image_urls) — распознаёт документы по фото. Провайдер
     выбирается в config.yaml (dify.vision.provider):
       - dify       : Dify-воркфлоу vision_assistant.yml (промты внутри ассистента).
       - openrouter : прямой вызов vision-модели через OpenRouter API; промты
                      передаются из кода (_VISION_SYSTEM_PROMPT ниже).

  2. fill_application(extracted) — отправляет извлечённые данные в отдельный
     Dify-ассистент (`dify.doc_fill_app_key`, см. document_assistant.yml), который
     раскладывает их по полям заявления.

Оба шага корректно деградируют до детерминированного офлайн-фолбэка, если провайдер
не настроен или недоступен. Промты для Dify — в PROMPTS.md.
"""
from __future__ import annotations

import json
import logging

import httpx

from app.config import Config
from app.docs.forms import DEFAULT_MEASURE, normalize_application

log = logging.getLogger("docs.ai")

# Промт для прямого вызова vision-модели (OpenRouter и любой OpenAI-compatible).
# При использовании Dify-провайдера промт уже встроен в vision_assistant.yml.
_VISION_SYSTEM_PROMPT = """\
Ты — ассистент контакт-центра поддержки участников СВО Ленинского городского округа \
Московской области. На вход поступают ФОТОГРАФИИ документов заявителя: паспорт РФ, \
удостоверение «Ветеран боевых действий», квитанция/ЕПД с лицевыми счетами ЖКУ, \
свидетельства о рождении детей, реквизиты банковского счёта.

Задачи:
1. Распознай документы и извлеки данные заявителя.
2. Определи доступную меру социальной поддержки. Если есть удостоверение ВБД или \
подтверждение участия в СВО — основная мера: «Ежемесячная денежная компенсация \
расходов на оплату ЖКУ» (категория «Ветеран боевых действий (участник СВО)», код 061).
3. Верни СТРОГО JSON по схеме (без текста до/после, без ```):

{
  "measure_key": "zhku_compensation",
  "measure_title": "Ежемесячная денежная компенсация расходов на оплату ЖКУ",
  "category": "Ветеран боевых действий (участник СВО)",
  "category_code": "061",
  "department": "Министерство социального развития Московской области, Ленинское управление социальной защиты населения",
  "applicant": {
    "fio": "Фамилия Имя Отчество",
    "birth_date": "ДД.ММ.ГГГГ",
    "passport_series": "0000",
    "passport_number": "000000",
    "passport_issued": "кем и когда выдан",
    "address": "адрес регистрации",
    "phone": "+7 ...",
    "email": ""
  },
  "ownership": "частное | муниципальное | государственное",
  "rooms": "число комнат, если видно",
  "family": [{"fio": "...", "birth_date": "ДД.ММ.ГГГГ", "relation": "супруга|сын|дочь|..."}],
  "providers": [{"name": "поставщик ЖКУ", "account": "номер лицевого счёта"}],
  "payment": {"method": "bank|post", "bank": "название банка", "account": "номер счёта"},
  "missing": ["чего не хватает для оформления, по-русски"],
  "confidence": 0.0,
  "summary_note": "1–2 предложения для гражданина: что распознано и на что он имеет право"
}

Правила:
- Не выдумывай данные. Чего не видно на фото — оставь пустой строкой "" и добавь пункт в "missing".
- Серию и номер паспорта верни цифрами, даты — в формате ДД.ММ.ГГГГ.
- confidence — твоя уверенность в распознавании (0..1).
- Никакого текста вне JSON.\
"""

_VISION_USER_TEXT = "Распознай приложенные фотографии документов и заполни JSON."


def _configured(value: str) -> bool:
    text = (value or "").strip().lower()
    if not text:
        return False
    return not any(m in text for m in ("xxxxxxxx", "change-me", "replace_with", "replace-with"))


def _extract_json(raw) -> dict | None:
    text = str(raw or "").strip().replace("```json", "").replace("```", "").strip()
    try:
        parsed = json.loads(text)
    except Exception:  # noqa: BLE001
        start, end = text.find("{"), text.rfind("}")
        if start >= 0 and end > start:
            try:
                parsed = json.loads(text[start:end + 1])
            except Exception:  # noqa: BLE001
                return None
        else:
            return None
    return parsed if isinstance(parsed, dict) else None


class DocAI:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.base_url = cfg.dify.base_url.rstrip("/")
        self.timeout = 90.0

    # ---- шаг 1: распознавание фотографий -----------------------------------

    async def analyze_documents(self, image_urls: list[str], user_key: str) -> dict:
        """Распознаёт документы по фото и предлагает меру поддержки.

        Возвращает нормализованную структуру заявления (см. forms.normalize_application)
        с дополнительным полем `source` (dify | openrouter | local).
        """
        vcfg = self.cfg.dify.vision
        try:
            if vcfg.provider == "openrouter":
                if _configured(vcfg.openrouter_api_key) and vcfg.openrouter_model.strip():
                    data = await self._ask_vision_openrouter(image_urls)
                    if data:
                        data["source"] = "openrouter"
                        return normalize_application(data)
                    log.warning("OpenRouter vision returned no data, using local fallback")
                else:
                    log.warning("OpenRouter vision not configured (missing api_key or model), using local fallback")
            else:
                key = self.cfg.dify.doc_vision_app_key
                if _configured(key):
                    data = await self._ask_vision_dify(image_urls, key, user_key)
                    if data:
                        data["source"] = "dify"
                        return normalize_application(data)
        except Exception as exc:  # noqa: BLE001
            log.warning("Vision %s failed, using local fallback: %s", vcfg.provider, exc)

        result = _fallback_extract(len(image_urls))
        result["source"] = "local"
        return normalize_application(result)

    async def _ask_vision_dify(self, image_urls: list[str], key: str, user_key: str) -> dict | None:
        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        files = [
            {"type": "image", "transfer_method": "remote_url", "url": url}
            for url in image_urls if url
        ]
        body = {
            "inputs": {},
            "query": "Распознай документы и предложи меру поддержки.",
            "response_mode": "blocking",
            "user": user_key,
            "files": files,
        }
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.post(f"{self.base_url}/chat-messages", headers=headers, json=body)
            if resp.status_code >= 400:
                log.error("Vision Dify error %s: %s", resp.status_code, resp.text[:400])
                return None
            data = resp.json()
        return _extract_json(data.get("answer", ""))

    async def _ask_vision_openrouter(self, image_urls: list[str]) -> dict | None:
        vcfg = self.cfg.dify.vision
        content: list[dict] = [{"type": "text", "text": _VISION_USER_TEXT}]
        for url in image_urls:
            if url:
                content.append({"type": "image_url", "image_url": {"url": url}})
        body = {
            "model": vcfg.openrouter_model,
            "messages": [
                {"role": "system", "content": _VISION_SYSTEM_PROMPT},
                {"role": "user", "content": content},
            ],
            "temperature": vcfg.temperature,
        }
        headers = {
            "Authorization": f"Bearer {vcfg.openrouter_api_key}",
            "Content-Type": "application/json",
        }
        base = vcfg.openrouter_base_url.rstrip("/")
        async with httpx.AsyncClient(timeout=vcfg.timeout) as client:
            resp = await client.post(f"{base}/chat/completions", headers=headers, json=body)
            if resp.status_code >= 400:
                log.error("Vision OpenRouter error %s: %s", resp.status_code, resp.text[:400])
                return None
            data = resp.json()
        raw = data.get("choices", [{}])[0].get("message", {}).get("content", "")
        return _extract_json(raw)

    # ---- шаг 2: заполнение заявления ---------------------------------------

    async def fill_application(self, extracted: dict, user_key: str) -> dict:
        """Раскладывает извлечённые данные по полям заявления (Dify или фолбэк)."""
        key = self.cfg.dify.doc_fill_app_key
        if _configured(key):
            try:
                data = await self._ask_fill(extracted, key, user_key)
                if data:
                    merged = normalize_application(data)
                    merged["source"] = "dify"
                    return merged
            except Exception as exc:  # noqa: BLE001
                log.warning("Doc-fill Dify failed, using local fallback: %s", exc)
        # Фолбэк: извлечённые данные уже нормализованы — используем как есть.
        out = normalize_application(extracted)
        out["source"] = extracted.get("source", "local")
        return out

    async def _ask_fill(self, extracted: dict, key: str, user_key: str) -> dict | None:
        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        body = {
            "inputs": {},
            "query": json.dumps(extracted, ensure_ascii=False),
            "response_mode": "blocking",
            "user": user_key,
        }
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.post(f"{self.base_url}/chat-messages", headers=headers, json=body)
            if resp.status_code >= 400:
                log.error("Doc-fill Dify error %s: %s", resp.status_code, resp.text[:400])
                return None
            data = resp.json()
        return _extract_json(data.get("answer", ""))


def _fallback_extract(n_photos: int) -> dict:
    """Детерминированный демо-результат распознавания (когда Dify не настроен).

    Имитирует распознанные паспорт + удостоверение ВБД + квитанцию ЕПД, чтобы весь
    сценарий «фото → мера → заявление → подтверждение» работал без визуальной модели.
    """
    return {
        "measure_key": DEFAULT_MEASURE["key"],
        "measure_title": DEFAULT_MEASURE["title"],
        "category": DEFAULT_MEASURE["category"],
        "category_code": DEFAULT_MEASURE["category_code"],
        "department": DEFAULT_MEASURE["department"],
        "applicant": {
            "fio": "Смирнов Сергей Иванович",
            "birth_date": "14.03.1988",
            "passport_series": "46 14",
            "passport_number": "778512",
            "passport_issued": "ГУ МВД России по Московской области, 25.06.2014",
            "address": "Московская область, г. Видное, ул. Школьная, д. 24, кв. 17",
            "phone": "+7 916 200-31-44",
            "email": "",
        },
        "ownership": "частное",
        "rooms": "2",
        "family": [
            {"fio": "Смирнова Анна Петровна", "birth_date": "02.09.1990", "relation": "супруга"},
            {"fio": "Смирнов Иван Сергеевич", "birth_date": "11.05.2016", "relation": "сын"},
        ],
        "providers": [
            {"name": "МосОблЕИРЦ", "account": "5012 778 512"},
            {"name": "АО «Мособлгаз»", "account": "61-778-512"},
        ],
        "payment": {"method": "bank", "bank": "ПАО Сбербанк", "account": "40817810000000012345"},
        "missing": [] if n_photos >= 2 else ["квитанция ЕПД (лицевой счёт)"],
        "confidence": 0.82,
        "summary_note": (
            "Распознаны паспорт и удостоверение «Ветеран боевых действий». Заявитель "
            "имеет право на ежемесячную денежную компенсацию расходов на оплату ЖКУ."
        ),
    }
