"""Загрузка и валидация конфигурации из YAML-файла (вместо запрещённого .env).

Путь к конфигу выбирается так (по приоритету):
  1. аргумент load_config(path=...)
  2. переменная окружения CONFIG_PATH
  3. ./config.yaml (по умолчанию)
"""
from __future__ import annotations

import os
from functools import lru_cache

import yaml
from pydantic import BaseModel, Field


class ServerCfg(BaseModel):
    host: str = "0.0.0.0"
    port: int = 8080
    api_key: str = ""  # X-Api-Key для /excel/extract


class ExcelCfg(BaseModel):
    max_chars: int = 90000
    drop_empty_cells: bool = True


class DatasetCfg(BaseModel):
    api_key: str = ""
    dataset_id: str = ""


class DocVisionCfg(BaseModel):
    """Провайдер для шага ① (распознавание документов по фото).

    provider:
      - dify       : Dify-воркфлоу (vision_assistant.yml), промты внутри ассистента.
                     Требует заполненного dify.doc_vision_app_key.
      - openrouter : Прямой вызов vision-модели через OpenRouter API
                     (POST /chat/completions). Промты передаются из кода.
    """

    provider: str = "dify"  # dify | openrouter
    openrouter_base_url: str = "https://openrouter.ai/api/v1"
    openrouter_api_key: str = ""
    openrouter_model: str = ""  # напр. "google/gemini-2.5-flash"
    temperature: float = 0.1
    timeout: float = 90.0


class DifyCfg(BaseModel):
    base_url: str = "https://dify.t1v.scibox.tech/v1"
    max_app_key: str = ""
    # Отдельный Dify-воркфлоу для анализа фотографий документов (визуальная модель).
    # Используется только при vision.provider=dify.
    doc_vision_app_key: str = ""
    # Отдельный Dify-ассистент, заполняющий заявление по извлечённым данным.
    doc_fill_app_key: str = ""
    dataset: DatasetCfg = Field(default_factory=DatasetCfg)
    vision: DocVisionCfg = Field(default_factory=DocVisionCfg)


class MaxCfg(BaseModel):
    api_base_url: str = "https://platform-api.max.ru"
    bot_token: str = ""
    operator_chat_id: str = ""
    questions_before_offer: int = 3
    confidence_threshold: float = 0.6
    # Порог тематической релевантности (0..1): запросы не по теме господдержки СВО
    # с уверенностью ниже порога отклоняются базовым сообщением и НЕ доходят до
    # операторов. См. поля on_topic / topic_confidence структурированного ответа Dify.
    topic_threshold: float = 0.5
    # true → uvicorn сам опрашивает MAX в фоне (long polling), вебхук не нужен.
    # Не включайте одновременно с активной подпиской на вебхук.
    polling: bool = False


class StorageCfg(BaseModel):
    sqlite_path: str = "./data/state.db"


class AuthCfg(BaseModel):
    """Авторизация веб-кабинета в стиле ЕСИА на базе Ory Kratos.

    Всё разворачивается на сервере (см. deploy/kratos/docker-compose.yml).

    mode:
      - demo   : вход проверяется по локальному списку `users` (работает сразу,
                 без поднятого Kratos — удобно для демонстрации и offline);
      - kratos : учётные данные проверяются через Kratos Identity API
                 (self-service login flow, `kratos_public_url`).
    """

    enabled: bool = True
    mode: str = "demo"  # demo | kratos
    # Адрес публичного API Kratos (для mode=kratos). На сервере — http://kratos:4433.
    kratos_public_url: str = "http://localhost:4433"
    # Секрет для подписи cookie-сессии кабинета (HMAC). СМЕНИТЕ на проде.
    session_secret: str = "change-me-please-set-a-long-random-secret"
    # Время жизни сессии в часах.
    session_ttl_hours: int = 12
    # Демо-пользователи: identifier (телефон/email/логин) → пароль и отображаемое имя.
    demo_users: list[dict] = Field(
        default_factory=lambda: [
            {"identifier": "operator@mosreg.ru", "password": "kontakt2026",
             "name": "Иванова О. П.", "role": "Оператор"},
            {"identifier": "admin@mosreg.ru", "password": "admin2026",
             "name": "Петров С. А.", "role": "Администратор"},
        ]
    )


class WebAiCfg(BaseModel):
    """ИИ для веб-черновиков и заметок.

    provider:
      - local: без внешнего ИИ, только шаблон;
      - dify: отдельное Dify-приложение, например простое LLM-приложение;
      - openai_compatible: прямой вызов модели через /chat/completions.
    """

    provider: str = "local"
    dify_base_url: str = ""
    dify_app_key: str = ""
    # auto: сначала /chat-messages, затем /completion-messages.
    # chat: только /chat-messages. completion: только /completion-messages.
    dify_mode: str = "auto"
    # Имя input-переменной в Dify completion-приложении.
    dify_input_variable: str = "query"
    openai_base_url: str = ""
    openai_api_key: str = ""
    openai_model: str = ""
    temperature: float = 0.2
    timeout: float = 60.0


class WebCfg(BaseModel):
    """Веб-интерфейс «Контакт-центр» (кабинет оператора/администрации).

    Раздаётся тем же uvicorn на том же внешнем порту, что и API — отдельный
    сервер не нужен. Регистрация не требуется (по заданию)."""

    enabled: bool = True
    title: str = "Контакт-центр — Господдержка СВО"
    # Путь к Excel-таблице УСВО (источник персональных карточек и аналитики).
    usvo_xlsx: str = "../USVO_tablitsa_1_plus_49_synthetic_rows_dates_addresses_fixed.xlsx"
    # Текст базы знаний — используется для офлайн-предложений по льготам,
    # если Dify не настроен.
    kb_text: str = "../Информация для базы знаний.txt"
    # УСВО, с которым не было контакта дольше этого срока, попадает в аналитику.
    contact_stale_days: int = 90
    # Список операторов для назначения ответственного по обращению.
    operators: list[str] = Field(
        default_factory=lambda: ["Оператор администрации"]
    )
    ai: WebAiCfg = Field(default_factory=WebAiCfg)
    # Если в БД ещё нет реальных обращений (бот не запускался) — показать
    # обращения, синтезированные из таблицы УСВО.
    seed_appeals: bool = True


class Config(BaseModel):
    server: ServerCfg = Field(default_factory=ServerCfg)
    excel: ExcelCfg = Field(default_factory=ExcelCfg)
    dify: DifyCfg = Field(default_factory=DifyCfg)
    max: MaxCfg = Field(default_factory=MaxCfg)
    storage: StorageCfg = Field(default_factory=StorageCfg)
    web: WebCfg = Field(default_factory=WebCfg)
    auth: AuthCfg = Field(default_factory=AuthCfg)
    schedule_file: str = "./data/schedule.yaml"


def load_config(path: str | None = None) -> Config:
    path = path or os.environ.get("CONFIG_PATH", "config.yaml")
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Не найден файл конфигурации: {path}. "
            f"Скопируйте config.example.yaml в config.yaml и заполните значения."
        )
    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    return Config(**data)


@lru_cache(maxsize=1)
def get_config() -> Config:
    """Кэшированный конфиг для всего приложения (читается один раз при старте)."""
    return load_config()
